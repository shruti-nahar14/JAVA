

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		operation1 op=new operation1();
	     customer cust[]=op.create();
	     op.calculate(cust);
	     op.display(cust);
	  }

}
