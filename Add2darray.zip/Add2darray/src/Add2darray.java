
public class Add2darray {
	public static void main(String[] args)
	{
	int mat1[][], mat2[][], mat3[][];
	boolean b;
	operationAdd op=new operationAdd();
    mat1=op.createmat1();
	System.out.println("Mat1 memory allocated ");
	
	mat2=op.createmat2();
	System.out.println("Mat2 memory alloacted ");
	System.out.println("enter elements of matrix1 ");
	op.Acceptmat1(mat1);
	System.out.println("Display elements of matrix1 ");
	op.displaymat1(mat1);
	System.out.println("enter elements of matrix2 ");
	op.Acceptmat2(mat2);
	System.out.println("Display elements of matrix2 ");
	op.displaymat2(mat2);
	System.out.println("check validaty ");
	b=op.validatearr(mat1,mat2);
	if(b==true)
	{
		mat3=op.addmat(mat1, mat2);
		System.out.println("Dislpay adddtion ");
		op.displayadd(mat3);
	}
	else
	{
		System.out.println("Addition not possible ");
	}
}
}
