
public class Piaino extends Instrument{

	@Override
	public void play() {
		System.out.println("tan tan tan ");
	}

}
