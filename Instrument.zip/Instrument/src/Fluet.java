
public class Fluet extends Instrument {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("toot toot toot");
	}

}
