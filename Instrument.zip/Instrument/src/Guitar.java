
public class Guitar extends Instrument{

	@Override
	public void play() {
		System.out.println("tin tin tin");
	}

}
