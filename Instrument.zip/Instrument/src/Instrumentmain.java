import java.util.Scanner;

public class Instrumentmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of object to be created ");
		int n=sc.nextInt();
		Instrument arr[]=new Instrument[n];
		for(int i=0;i<n;i++)
		{
		System.out.println("1.GUITAR \n2.FLUET \n3.PIANIO ");
		System.out.println("Enter the choice ");
		int ch=sc.nextInt();
		if(ch==1)
		{
		arr[i]=new Guitar();
		display(arr);
		}
		else if(ch==2)
		{
		arr[i]=new Fluet();
		display(arr);
		}
		else if(ch==3)
		{
		arr[i]=new Piaino();
		display(arr);
		}
		arr[i]=null;
		}

	}
	public static void display(Instrument arr[])
	{
		for(Instrument t:arr)
		{
			if(t instanceof Guitar)
			{
				System.out.println("--------------------Guitar-----------------------");
				t.play();
			}
			if(t instanceof Fluet)
			{
				System.out.println("--------------------Fluet-----------------------");
				t.play();
			}
			if(t instanceof Piaino)
			{
				System.out.println("--------------------Piaino"
						+ "-----------------------");
				t.play();
			}
		}

	}
}
