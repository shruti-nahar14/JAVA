
public class Developer extends Employee{
	private int empbonus;
	public Developer(int empid, String empname, double empsal, int empbonus) {
		super(empid, empname, empsal);
		this.empbonus = empbonus;
	}
   public int getEmpbonus() {
		return empbonus;
	}

	public void setEmpbonus(int empbonus) {
		this.empbonus = empbonus;
	}
	

}
