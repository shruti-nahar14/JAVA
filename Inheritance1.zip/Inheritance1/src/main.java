
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager mobj=new Manager(101,"shruti",5000,20);
		System.out.println("----------------Manager Details----------------------");
		display(mobj);
		Developer dobj=new Developer(102,"shubham",5000,500);
		System.out.println("---------------Developer Details---------------------");
		display(dobj);
		System.out.println("---------------THANKYOU-----------------");
		}
	public static void display(Employee eobj)
	{
		System.out.println("Employee Id "+eobj.getEmpid());
		System.out.println("Employee Name "+eobj.getEmpname());
		System.out.println("Employee Salary "+eobj.getEmpsal());
		if(eobj instanceof Manager)
		{
			Manager m=(Manager)eobj;
			System.out.println("No Of Hours: "+m.getNoofhrs());
		}
		if(eobj instanceof Developer)
		{
			Developer d=(Developer)eobj;
			System.out.println("No Of Hours: "+d.getEmpbonus());
		}
	}

}
