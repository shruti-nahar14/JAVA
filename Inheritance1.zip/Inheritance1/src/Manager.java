
public class Manager extends Employee{
	private int noofhrs;

	public Manager(int empid, String empname, double empsal, int noofhrs) {
		super(empid, empname, empsal);
		this.noofhrs = noofhrs;
	}

	public int getNoofhrs() {
		return noofhrs;
	}

	public void setNoofhrs(int noofhrs) {
		this.noofhrs = noofhrs;
	}
	

}
