package inheritance;

public class grandfather 
{
	private int gage;
	public grandfather(int gage)
	{
		this.gage=gage;
	}
	public void showage()
	{
		System.out.println("grandfather age is "+gage);
	}
}
