package inheritance;
import java.util.Scanner;
public class inheritance {
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	son s1=new son(20);
	s1.showage();
	}

}
