package array2D;
import java.util.Scanner;
public class array2D {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int arr[][]=null;
		operation2d d=new operation2d();
		System.out.println("Allocate memmory for 2d array ");
		arr=d.createmat();
		System.out.println("enter the elements in 2d array ");
		d.Acceptmat(arr);
		System.out.println("Elements of 2d array are ");
		d.displaymat(arr);
	}
}