import java.util.Scanner;

public class Automobilemain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Automobile a=null;
		Scanner sc=new Scanner(System.in);
		int ch;
		do
		{
			System.out.println("1.CAR \n2.BIKE");
			System.out.println("Enter your choice ");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:
				do
				{
				System.out.println("WELCOME TO CAR SECTION ");
				System.out.println("1.MAURTI \n2.SWIFT \n3.BMW ");
				ch=sc.nextInt();
				if(ch==1)
				{
					a=new maurti();
				}
				if(ch==2)
				{
					a=new swift();
				}
				if(ch==3)
				{
					a=new BMW();
				}
				System.out.println("---------------------------------------");
				display(a);
				System.out.println("Do you want to continue with car section ");
			    }while(sc.next().equals("yes"));
			break;
			case 2:
			do
			{
				System.out.println("WELCOME TO BIKE SECTION ");
				System.out.println("1.HEROHONDA \n2.BAJAJ \n3.TVS ");
				ch=sc.nextInt();
				if(ch==1)
				{
					a=new Herohonda();
					
				}
				if(ch==2)
				{
					a=new Bajaj();
				}
				if(ch==3)
				{
				   a=new TVS();	
				}
				System.out.println("---------------------------------------");
				display(a);
				System.out.println("Do you want to continue with bike section ");
		        }while(sc.next().equals("yes"));
			break;
			}
			
		System.out.println("Do you want to continue!!!!!!!");
		}while(sc.next().equals("yes"));
	System.out.println("-------------------------THANKYOU-------------------------------");
	}
public static void display(Automobile a)
{
	System.out.println(a);
}
}