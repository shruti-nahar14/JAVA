
public interface bike extends Automobile {
	int noofcc();
}
