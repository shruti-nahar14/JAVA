
public interface Automobile {
	String getmodel();
	String getcolour();
	double getprice();

}
