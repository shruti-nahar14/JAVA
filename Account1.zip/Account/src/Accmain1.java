
public class Accmain1 {

	public static void main(String[] args) {
	Accountmanager obj=new Accountmanager();
	Account aobj=obj.create();
	obj.display(aobj);
	}
}
