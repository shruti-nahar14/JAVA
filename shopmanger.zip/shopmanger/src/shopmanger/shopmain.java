package shopmanger;

public class shopmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      operation op=new operation();
     customer cust[]=op.create();
      op.calculate(cust);
     op.display(cust);
   
	}

}
